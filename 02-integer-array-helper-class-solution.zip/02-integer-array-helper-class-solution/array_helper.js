// your class code here

class ArrayHelper{

    /**
     *  Array Helper constructor
     * 
     *  the 'value' argument could an array on length to generate a random array
     * 
     * @param {*} value 
     */
    constructor(value = null){


        if ( Array.isArray(value) ){

            this.integersArray = value;

            console.log(value)

        }else if( Number.isInteger (value) ){

            this.integersArray = this.genRandomArray(value)

            console.log('Random array on length "' + value + '" is generated. \n')
            console.log(this.integersArray);

        }else{

            console.log('Please, provide an array of integers or a length to generate a random one.')

        }

    }

    /**
     *  Generate random array on integers with a specific length
     * 
     * @param {*} length 
     * @returns 
     */
    genRandomArray( length = 1 ){

        // validating a minimum and maximum lengths (not values) to avoid negative values, and zero-length
        if ( length >= 1 && length <= 100 ){

            // Here is a suggested method using built-in JS functions
            //to generate an random array on integers between numbers 0 and 100
            return Array(length).fill().map(() => Math.floor(100 * Math.random()));

        }else{
            // the throw functions throws an error and exits the code.
            throw 'Array length must be between 1 and 100';

        }
        
    }

    /**
     *  Returns the set array (either randomly generated or set manually via the constructor)
     * 
     * @returns
     */
    getArray(){
        return this.integersArray;
    }

    /**
     * Extract the even numbers from the array.
     * 
     */
    getEvenNumbers(){

        // one way is by using the 'filter()' function
        return this.integersArray.filter(number => {return number % 2 === 0;});

        
        // another way is by using for loop like this
        /* 
        
        let evenArray = [];
        for ( let i = 0; i < this.integersArray.length; i++ ){
            if ( (this.integersArray[i] % 2) === 0 ){
                evenArray.push(this.integersArray[i])
            }
        } 
        
        */

    }
    /**
     * Extract the odd numbers from the array.
     * 
     */
    getOddNumbers(){

        // one way is by using the 'filter()' function
        return this.integersArray.filter(number => {return number % 2 !== 0;});
        //-----------------------------------------------------------

        // another way is by using for loop like this
        /* 
        
            let evenArray = [];
            for ( let i = 0; i < this.integersArray.length; i++ ){
                if ( (this.integersArray[i] % 2) !== 0 ){
                    evenArray.push(this.integersArray[i])
                }
            } 
        
        */

    }

    /**
     * 
     * Get the array values average.
     * 
     * @returns 
     */
    getAvg(){


        // traditional way by using for loop
        /*
            let sum = 0;

            for ( let i = 0; i < this.integersArray.length; i++ ){
                sum +=this.integersArray[i];
            }

            return (sum/this.integersArray.length);
        */
        //-----------------------------------------------------------
        // another way by using for loop
        /*
            let sum = 0;

            for (const value of arr) {
                sum += value;
            }

            return (sum/this.integersArray.length);
        */
        //-----------------------------------------------------------
        // An advanced way is by using reduce() function, a,b are pointing to the current and next elements

        return this.integersArray.reduce((accumulator, value) => accumulator + value, 0) / this.integersArray.length;

        // The reduce() method explained
        /**
         * To get the sum of an array of numbers:
         * Use the Array.reduce() method to iterate over the array.
         * Set the initial value in the reduce method to 0.
         * On each iteration, return the sum of the accumulated value and the current number.
         * 
         * The accumulator parameter is initially set to 0 because that's what we passed as the second argument to the reduce method.
         * 
         * To read more about the reduce method:
         * 
         * https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array/Reduce
         *  
         */        
        //-----------------------------------------------------------
    }

    /**
     * Returns the minimum value
     * 
     * @returns 
     */
    getMinValue(){
        return Math.min.apply(Math, this.integersArray);
        // or by using a for loop
    }

    /**
     * Returns the maximum value
     * 
     * @returns 
     */
    getMaxValue(){
        return Math.max.apply(Math, this.integersArray);
        // or by using a for loop
    }
}